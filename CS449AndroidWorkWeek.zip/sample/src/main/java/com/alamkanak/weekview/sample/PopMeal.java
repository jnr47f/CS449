package com.alamkanak.weekview.sample;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;

import com.alamkanak.weekview.WeekViewEvent;

import java.util.Calendar;
import java.util.List;

/**
 * Created by Jenny on 5/7/2017.
 */


abstract class PopMeal extends BasicActivity {
    BaseActivity ba;
    Button btnDatePicker, btnTimePicker;
    EditText txtDate, txtTime, calorieEditText, RecipeEdit;
    private int mYear, mMonth, mDay, mHour, mMinute;
    private String name, color, type, recipe;
    int calories;

    //end time is one hour after start time

    //Get date and time

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnDatePicker=(Button)findViewById(R.id.btn_date);
        btnTimePicker=(Button)findViewById(R.id.btn_time);
        txtDate=(EditText)findViewById(R.id.in_date);
        txtTime=(EditText)findViewById(R.id.in_time);

        mWeekView.setOnClickListener();
        btnTimePicker.setOnClickListener((View.OnClickListener) this);
    }

    public void onClick(View v) {

        if (v == btnDatePicker) {

            // Get Current Date
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);


            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            txtDate.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if (v == btnTimePicker) {

            // Get Current Time
            final Calendar c = Calendar.getInstance();
            mHour = c.get(Calendar.HOUR_OF_DAY);
            mMinute = c.get(Calendar.MINUTE);

            // Launch Time Picker Dialog
            TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                    new TimePickerDialog.OnTimeSetListener() {

                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay,
                                              int minute) {

                            txtTime.setText(hourOfDay + ":" + minute);
                        }
                    }, mHour, mMinute, false);
            timePickerDialog.show();
        }
    }

    public void onCheckboxClicked(View view) {
        //is the view now checked?
        boolean checked = ((CheckBox) view).isChecked();

        //check which checkbox was clicked
        switch (view.getId()) {
            case R.id.breakfast:
                if (checked) {
                    type = "breakfast";
                    color = "event_color_01";
                    break;
                }
            case R.id.lunch:
                if (checked) {
                    type = "lunch";
                    color = "event_color_02";
                }
            case R.id.Dinner:
                if (checked) {
                    type = "dinner";
                    color = "event_color_03";
                }
            case R.id.Snack:
                if (checked) {
                    type = "snack";
                    color = "event_color_04";
                }
        }

    }
    Button b = (Button) findViewById(R.id.saveButton);
        @Override
        public List<? extends WeekViewEvent> onMonthChange(int newYear, int day, int newMonth, int starthour, int startminute, String name, int calorie, String color) {
        return super.onMonthChange(mYear, mDay, mMonth, mHour, mMinute, RecipeEdit.getText().toString(), Integer.parseInt(RecipeEdit.getText().toString()), color);

    }

}



package com.alamkanak.weekview.sample;

import android.graphics.Typeface;
import android.os.Bundle;

import com.alamkanak.weekview.WeekViewEvent;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


public abstract class BasicActivity extends BaseActivity {

    public static int caloriecount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        Typeface customTypeface = Typeface.createFromAsset(this.getAssets(), "fonts/Raleway/Raleway-Medium.ttf");
        mWeekView.setTypeface(customTypeface);
        int caloriecount =0;
    }

    public List<? extends WeekViewEvent> onMonthChange(int newYear, int day,  int newMonth, int starthour, int startminute, String name, int calorie, String color) {
        // Populate the week view with some events.
        List<WeekViewEvent> events = new ArrayList<WeekViewEvent>();
       caloriecount =0;

       Calendar startTime = Calendar.getInstance();
        startTime.set(Calendar.DAY_OF_WEEK, day);
        startTime.set(Calendar.HOUR_OF_DAY, starthour);
        startTime.set(Calendar.MINUTE, startminute);
        startTime.set(Calendar.MONTH, newMonth - 1);
        startTime.set(Calendar.YEAR, newYear);
        Calendar endTime = (Calendar) startTime.clone();
        endTime.set(Calendar.HOUR_OF_DAY, (starthour+1));
        endTime.set(Calendar.MINUTE, startminute);
        endTime.set(Calendar.MONTH, newMonth - 1);
        WeekViewEvent event = new WeekViewEvent(1, getEventTitle(name,startTime), startTime, endTime);

        switch(color) {
            case "event_color_01":
                event.setColor(getResources().getColor(R.color.event_color_01));
                break;
            case "event_color_02":
                event.setColor(getResources().getColor(R.color.event_color_02));
                break;
            case "event_color_03":
                event.setColor(getResources().getColor(R.color.event_color_03));
                break;
            case "event_color_04":
                event.setColor(getResources().getColor(R.color.event_color_04));
                break;
        }
                caloriecount += calorie;
                events.add(event);

                return events;
        }
}

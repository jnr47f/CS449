package com.alamkanak.weekview.sample;

import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

/**
 * Created by Jenny on 5/7/2017.
 */

class Pop extends MainActivity {
   // @Override
    protected void OnCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

        setContentView(R.layout.uploadpop);

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        int width = dm.widthPixels;
        int height = dm.heightPixels;

        getWindow().setLayout((int)(height * .8), (int)(width * .6));


        Button b = (Button) findViewById(R.id.uploadPopbutton);
        final EditText mEdit = (EditText)findViewById(R.id.uploadpop);

        b.setOnClickListener(
                new View.OnClickListener()
                {
                    public void onClick(View view)
                    {
                        Log.v("Upload", mEdit.getText().toString());
                        //save into database
                    }
                });
    }

}
